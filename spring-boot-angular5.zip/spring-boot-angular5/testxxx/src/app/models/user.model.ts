export class User {userUrl

  id: string;
  firstName: string;
  lastName: string;
  email: string;
}
